Parse.initialize('F5PDVVr50MdBrdBTQqp5fuksYRixEIX4GE0gkeK7','rdiBqEdXqKZ2GuTEyvmRsIEc2lanobhTh3rScSDM');

$(document).ready(function(){
	ENV = EnvironmentDetector();
});

//--------------------------------------------------------
$.ajaxSetup({
  cache: true
});
